<?php $__env->startSection('content'); ?>
<div class="">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                
                <!-- /.col -->
                
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10">
                    <div class="card">
                        <div class="card-header">
                            <h3>หัวข้อ </h3>
                        </div>
                        <div class="card-body">
                            
                            <table class="table">
                                <tr>
                                    <th>ชื่อ</th>

                                    <th>ที่อยู่</th>
                                    <th>ตัวเลือก</th>
                                </tr>


                                <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($s->closeDonate > now()): ?>
                                <tr>


                                    <td><?php echo e($s->name); ?></td>
                                    <td><?php echo e($s->address); ?></td>
                                    <td>
                                        <?php
                                            $id =[
                                                'id' =>$s->id,
                                            ];
                                            $id= Crypt::encrypt($id);
                                        ?>

                                        <?php if($s->level == '1'): ?>
                                        <a href="<?php echo e(route('donation.edit',['id'=>$id])); ?>"
                                            class="btn btn-outline-primary">donate</a>
                                        <?php elseif($s->level == '2'): ?>
                                        <a href="<?php echo e(route('donation.edit',['id'=>$id])); ?>"
                                            class="btn btn-outline-success">donate</a>
                                        <?php elseif($s->level == '3'): ?>
                                        <a href="<?php echo e(route('donation.edit',['id'=>$id])); ?>"
                                            class="btn btn-outline-warning">donate</a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('donation.edit',['id'=>$id])); ?>"
                                            class="btn btn-outline-danger">donate</a>
                                        <?php endif; ?>

                                    </td>
                                </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


</div>
<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.memberNav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>