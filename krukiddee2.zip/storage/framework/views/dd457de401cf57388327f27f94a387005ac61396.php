<?php $__env->startSection('content'); ?>


<div class="wpo-case-details-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col col-md-8">
                <div class="wpo-case-details-wrap">
                    <div class="wpo-case-details-img">
                        
                        <img src="<?php echo e(asset('storage/images/'.$s->picture)); ?>" alt="">
                    </div>
                    <div class="wpo-case-details-tab">
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#Description">รายละเอียด</a></li>
                            <li><a data-toggle="tab" href="#Donations">บริจาค</a></li>
                            
                        </ul>
                    </div>
                    <div class="wpo-case-details-text">
                        <div class="tab-content">
                            <div id="Description" class="tab-pane active">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="wpo-case-content">
                                            <div class="wpo-case-text-top">
                                                <h2><?php echo e($s->name.' '.$s->lastname); ?></h2>
                                                <div class="progress-section">
                                                    <div class="process">
                                                        <div class="progress">
                                                            <?php

                                            $per = ($s->totalDonate/$s->maxDonate)*100;
                                        ?>
                                                            <div class="progress-bar" role="progressbar"
                                                                style="width: <?php echo e($per); ?>%; max-width: 100%;" aria-valuenow="<?php echo e($per); ?>"
                                                                aria-valuemin="0" aria-valuemax="100">
                                                                <div class="progress-value"><span><?php echo e($per); ?></span>%</div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <ul>
                                                    <li><span>ยอดที่ได้รับ:</span><?php echo e(number_format($s->totalDonate)); ?>฿
                                                    </li>
                                                    <li><span>ยอดที่ต้องการ:</span> <?php echo e(number_format($s->maxDonate)); ?>฿
                                                    </li>
                                                    <li><span>มีผู้บริจาคไปแล้ว:</span> <?php echo e($sum); ?>ครั้ง</li>
                                                </ul>
                                                <div class="case-bb-text">
                                                    <h3>ข้อมูลนักเรียน</h3>
                                                    <?php echo $s->description1; ?>



                                                    
                                                </div>
                                                <div class="case-bb-text">
                                                    <h3>สิ่งที่นักเรียนต้องการรับบริจาคอื่นๆ</h3>
                                                    <?php echo $s->description2; ?>


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div id="Donations" class="tab-pane">
                                <form action=" <?php echo e(route('donation.store')); ?> " method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="wpo-donations-amount">
                                        <h2>รายละเอียดการบริจาค</h2>
                                        <h4>บัญชีของ : <?php echo e($s->bank_of); ?></h4>
                                        <h3>ธนาคาร : <?php echo e($s->bankName); ?></h3>
                                        <h3>ชื่อบัญชี : <?php echo e($s->bankAccountName); ?></h3>
                                        <h3>เลขที่บัญชี : <?php echo e($s->bankNumber); ?></h3>

                                    </div>
                                    <div class="wpo-donations-details">
                                        <h2>ยืนยันการบริจาค</h2>
                                        <div class="row">

                                            <div class="col-lg-12 col-12 form-group">
                                                <input type="number" class="form-control" name="price" id="price"
                                                    placeholder="จำนวนเงินที่บริจาค">
                                            </div>
                                            <div class="col-lg-12 col-12 form-group">
                                                <textarea class="form-control" name="description" id="description"
                                                    placeholder="แสดงความคิดเห็น"></textarea>
                                            </div>
                                            <div class="col-lg-12 col-12 form-group">
                                                <label for="pic">ยืนยันใบเสร็จการบริจาค</label>
                                                <input type="file" class="form-control" id="picture" name="picture"
                                                    placeholder="" required autofocus>
                                            </div>

                                        </div>
                                    </div>
                                    <input type="hidden" name="student_id" value="<?php echo e($s->id); ?>">
                                    <div class="submit-area">
                                        <button type="submit" class="theme-btn submit-btn">ยืนยันการบริจาค</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col col-md-4">
                <div class="wpo-blog-sidebar">

                    <div class="widget recent-post-widget">
                        <h3>นักเรียนที่ต้องการรับบริจาค</h3>
                        <?php $__currentLoopData = $max; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $myDateTime = DateTime::createFromFormat('Y-m-d', $m->closeDonate);
                                    $formattedweddingdate = $myDateTime->format('d-m-Y');
                                    $id =[
                                                'id' =>$m->id,
                                            ];
                                            $id= Crypt::encrypt($id); ?>
                        <div class="posts">
                            <div class="post">
                                <div class="img-holder">
                                     
                        <img src="<?php echo e(asset('storage/images/'.$m->picture)); ?>" style="  width: 100%;  max-height: 70px; height: auto;" alt="">
                                </div>
                                <div class="details">
                                    <h4><a
                                            href="<?php echo e(route('donation.cause',['id'=>$id])); ?>"><?php echo e($m->name.' '.$m->lastname); ?></a>
                                    </h4>

                                    <span class="date">ปิดรับบริจาควันที่ : <?php echo e($formattedweddingdate); ?></span>
                                </div>
                            </div>


                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(session('feedback')): ?>
<link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">
<script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>
<script>
    Swal.fire("<?php echo e(session('feedback')); ?>",'ขอบคุณที่ร่วมบริจาคกับเรา','success');
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.memberNav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>