<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Dashboard</h1>
                </div>
                <!-- /.col -->
                
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <?php $__currentLoopData = $stu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="col-lg-3 col-md-6 mb-3">
                    <div class="card h-100">
                        <a href="#"><img src="<?php echo e(asset('storage/images/'.$s->picture)); ?>" width="324" height="150"
                                class="card-img-top"></a>
                        <div class="card-body">
                            <h4 class="card-title">
                                <a href="#"><?php echo e($s->name.' '.$s->lastname); ?></a>
                            </h4>
                            <br>
                            <h5><?php echo e($s->bankAccountName); ?></h5>
                            <p class="card-text"><?php echo e($s->bankName); ?></p>
                        </div>
                        <div class="card-footer">




                            <div class="btn-toolbar justify-content-between" role="toolbar"
                                aria-label="Toolbar with button groups">
                                <?php if($s->closeDonate < now()): ?>
                                <div class="btn-group mr-1" role="group" aria-label="First group">

                                    <a href=" <?php echo e(route('nontification.create',['id'=>$s->id])); ?> "
                                        class="btn btn-outline-danger">เพิ่มคำขอบคุณ</a>

                            </div>

                            <?php endif; ?>

                            <div class="input-group">
                                <div class="btn-group" role="group" aria-label="3 group">
                                    <a class="btn btn-outline-info" href="<?php echo e(route('student.edit',['id'=>$s->id])); ?>">

                                        <li style="color: #0f5e52;" class="fa fa-pencil "></li>

                                    </a>

                                </div>
                                <div class="btn-group" role="group" aria-label="First group">
                                    <form action="<?php echo e(route('student.destroy',['id'=>$s->id])); ?>" method="POST"
                                        class="d-inline" onsubmit="return confirm('ต้องการลบข้อมูล?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button class="btn btn-outline-secondary ">

                                            <li style=" color: #545c5b;" class="fa fa-trash "></li>

                                        </button>

                                    </form>


                                </div>
                            </div>

                        </div>
                        
                    </div>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
        
</div>
</div>
</div>




</div>



</div>
<!-- /.container-fluid -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/teacherNav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>