<?php $__env->startSection('content'); ?>
<div class="">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Dashboard</h1>
                </div>
                <!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard v2</li>
                    </ol>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10">
                    <div class="card">
                        <div class="card-header">
                            <h3>บริจาคให้ : <?php echo e($stu->name); ?> </h3>
                        </div>
                        <div class="card-body">

                            
                            
                            <form novalidate class="<?php echo e(($errors->any()) ? 'was-validated' : 'needs-validation'); ?>"
                                action=" <?php echo e(route('donation.store')); ?> " method="POST" enctype="multipart/form-data">

                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="description">จำนวนเงินบริจาค</label>
                                    
                                    <input type="text" id="price" name="price" class="form-control<?php echo e($errors->has('price') ? ' is-invalid' : ''); ?>"  required autofocus>
                                    <?php if($errors->has('price')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('price')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                </div>

                                <label for="description">เพิ่มความคืดเห็น</label>
                                <textarea class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>"  name="description" id="exampleFormControlTextarea1"
                                    rows="3"required autofocus ></textarea>
                                    <?php if($errors->has('description')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>

                                <input type="file" class="form-control" id="picture" name="picture" required autofocus>

                                <input type="hidden" name="student_id" value="<?php echo e($stu->id); ?>">

                                <button type="submit" class="btn btn-primary mt-3">บันทึก</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.memberNav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>