<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-3">
            <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
        </div>
        <div class="col-lg-9">
            <form class="wpo-accountWrapper" method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>
                <div class="wpo-accountForm form-style">
                    <div class="fromTitle">
                        <h2>สมัครสมาชิก</h2>
                        <p>หากคุณต้องการร่วมบริจาค</p>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12 <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name">
                                Full Name
                            </label>
                            <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>"
                                required autofocus>
                                <?php if($errors->has('name')): ?>

                            <h5 class="error text-danger"><?php echo e($errors->first('name')); ?></h5>

                            <?php endif; ?>
                        </div>
                        <div class="col-lg-12 col-md-12 col-12 <?php echo e($errors->has('lastname') ? ' has-error' : ''); ?>">
                            <label for="name">Last Name</label>
                            <input id="lastname" type="text" class="form-control" name="lastname"
                                value="<?php echo e($lastname ?? old('lastname')); ?>" required autofocus>
                                <?php if($errors->has('lastname')): ?>

                            <h5 class="error text-danger"><?php echo e($errors->first('lastname')); ?></h5>

                            <?php endif; ?>
                        </div>
                        <div class="col-lg-12 col-md-12 col-12 <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label>Email</label>
                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>"
                                required>
                            <?php if($errors->has('email')): ?>

                            <h5 class="error text-danger"><?php echo e($errors->first('email')); ?></h5>

                            <?php endif; ?>
                        </div>

                        <div class="col-lg-12 col-md-12 col-12 <?php echo e($errors->has('tel') ? ' has-error' : ''); ?>">
                            <label>Tel</label>
                            <input id="tel" type="text" class="form-control" name="tel" value="<?php echo e($tel ?? old('tel')); ?>"
                                required autofocus>
                                <?php if($errors->has('tel')): ?>

                            <h5 class="error text-danger"><?php echo e($errors->first('tel')); ?></h5>

                            <?php endif; ?>
                        </div>
                        <div class="col-lg-12 col-md-12 col-12 <?php echo e($errors->has('Address') ? ' has-error' : ''); ?>">
                            <label>Address</label>
                            <input id="Address" type="text" class="form-control" name="Address"
                                value="<?php echo e($Address ?? old('Address')); ?>" required autofocus>
                                <?php if($errors->has('Address')): ?>

                            <h5 class="error text-danger"><?php echo e($errors->first('Address')); ?></h5>

                            <?php endif; ?>
                        </div>
                        <div class="col-lg-12 col-md-12 col-12 <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <div class="form-group">
                                <label>Password</label>
                                <input id="password" type="password" class="form-control" name="password" required>
                                <?php if($errors->has('password')): ?>

                            <h5 class="error text-danger"><?php echo e($errors->first('password')); ?></h5>

                            <?php endif; ?>
                            </div>
                            <span class="input-group-btn">
                                <button class="btn btn-default reveal3" type="button"><i
                                        class="glyphicon glyphicon-eye-open"></i></button>
                            </span>
                        </div>
                        <div class="col-lg-12 col-md-12 col-12">
                            <div class="form-group">
                                <label>Confirm Password</label>
                                <input id="password-confirm" type="password" class="form-control"
                                    name="password_confirmation" required>
                            </div>
                            <span class="input-group-btn">
                                <button class="btn btn-default reveal2" type="button"><i
                                        class="glyphicon glyphicon-eye-open"></i></button>
                            </span>
                        </div>
                        <input id="type" type="hidden" name="type" value="1">
                        <input id="schoolname" type="hidden" name="schoolname" value="0">
                        <input id="pic_id_card" type="hidden" name="pic_id_card" value="0">
                        <input id="id_card" type="hidden" name="id_card" value="1010101010101">
                        <div class="col-lg-12 col-md-12 col-12">
                            <button type="submit" class="wpo-accountBtn"> สมัครสมาชิก</button>
                        </div>
                    </div>

                </div>

            </form>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
<?php if($errors->any()): ?>


<link rel="stylesheet" href="<?php echo e(asset('css/sweetalert2.min.css')); ?>">
<script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>
<script>
    Swal.fire({
  icon: 'error',
  title: 'ไม่สามารถสมัครสมาชิกได้',
  text: 'กรุณาตรวจสอบข้อมูลการสมัคร',
  footer: 'มีชื่อผู้ใช้แล้ว? <a href="<?php echo e(route('login')); ?>"> เข้าสู่ระบบ</a>',
  showConfirmButton: false,
  showCloseButton: true,
})

</script>
<?php endif; ?>
<script>
    $(document).ready(function(){

  $('#tel').mask('000-000-0000');
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.memberNav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>