<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Dashboard</h1>
                </div>
                <!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard v2</li>
                    </ol>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">

            <div class="row">

                <div class="col-md-3"></div>
                <div class="col-md-5">
                    <div class="card">
                        <div class="card-header">
                        <h3 class="card-title">แก้ไขข้อมูลสมาชิก : <?php echo e($user->name); ?></h3>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        </div>

                        <div class="card-body">
                            <?php echo Form::model($user, ['novalidate','route' => ['admin.teacherUpdate'], 'method'
                            =>
                            'post', 'files' => true,'class'=> ($errors->any()) ? 'was-validated' : 'needs-validation']); ?>

                            <div class="form-group">
                                <label for="name">ชื่อ</label>
                                <?php echo e(Form::text('name', null,['class'=>'form-control ','required'])); ?>

                                <?php if($errors->has('name')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="lastname">นามสกุล</label>
                                <?php echo e(Form::text('lastname', null,['class'=>'form-control ','required'])); ?>

                                <?php if($errors->has('lastname')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('lastname')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="email">อีเมล์</label>
                                <?php echo e(Form::email('email', null,['class'=>'form-control ','required'])); ?>

                                <?php if($errors->has('email')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="tel">หมายเลขโทรศัพท์</label>
                                <?php echo e(Form::number('tel', null,['class'=>'form-control ','required'])); ?>

                                <?php if($errors->has('tel')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('tel')); ?></div>
                                <?php endif; ?>
                            </div>



                                <div class="form-group ">
                                    <label for="id_card">เลขบัตรประชาชน</label>
                                    <?php echo e(Form::text('id_card', null, ['class'=>'form-control','required'])); ?>

                                    <?php if($errors->has('id_card')): ?>
                                    <div class="invalid-feedback"><?php echo e($errors->first('id_card')); ?></div>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group ">
                                    <label for="schoolName">ชื่อโรงเรียน</label>
                                    <?php echo e(Form::text('schoolname', null, ['class'=>'form-control','required'])); ?>

                                    <?php if($errors->has('schoolname')): ?>
                                    <div class="invalid-feedback"><?php echo e($errors->first('schoolname')); ?></div>
                                    <?php endif; ?>
                                </div>



                            <div class="form-group ">
                                <label for="Address">ที่อยู่โรงเรียน</label>
                                <?php echo e(Form::text('Address', null, ['class'=>'form-control','required'])); ?>

                                <?php if($errors->has('Address')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('Address')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="picture" name="picture" required>
                                    <?php if($errors->has('picture')): ?>
                                    <div class="invalid-feedback"><?php echo e($errors->first('picture')); ?></div>
                                    <?php endif; ?>
                                    <label class="custom-file-label"
                                        for="validatedCustomFile">เลือกภาพใบกระกอบวิชาชีพ</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="password">รหัสผ่าน</label>
                                <?php echo e(Form::text('password',null,['class'=>'form-control'])); ?>

                                <?php if($errors->has('password')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('password')); ?></div>
                                <?php endif; ?>
                            </div>
                        <input type="hidden" value="<?php echo e($user->id); ?>" name="id">
                            <button type="submit" class="btn btn-primary">แก้ไขข้อมูลสมาชิก</button>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>


                </div>
            </div>



        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/adminNav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>