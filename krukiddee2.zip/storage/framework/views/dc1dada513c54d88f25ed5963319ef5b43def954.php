<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Dashboard</h1>
                </div>
                <!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard v2</li>
                    </ol>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <script>
        $(document).ready(function(){
          $("#myInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#myTable tr").filter(function() {
              $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
          });
        });
    </script>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Member ทั้งหมด</h3>
                            <input id="myInput" type="text" placeholder="Search..">

                        </div>
                        <div class="card-body">

                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>id</th>
                                        <th>ชื่อ</th>
                                        <th>email</th>
                                        <th>สถานะ</th>
                                        <th>เครื่องมือ</th>
                                    </tr>
                                </thead>
                                <tbody id="myTable">
                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php
                                        $id = Crypt::encrypt($s->id);
                                        ?>
                                        <td><?php echo e($s->id); ?></td>
                                        <td><?php echo e($s->name); ?></td>
                                        <td><?php echo e($s->email); ?></td>
                                        <td><?php echo e($s->status); ?></td>
                                        <td>

                                            <div class="btn-group">
                                                <button type="button" class="btn btn-secondary btn-sm"><i
                                                        class="fas fa-cog"></i></button>
                                                <button type="button"
                                                    class="btn btn-default btn-sm dropdown-toggle dropdown-icon"
                                                    data-toggle="dropdown"></button>
                                                    <span class="sr-only">Toggle Dropdown</span>
                                                    <div class="dropdown-menu" role="menu">
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('admin.editMember',['id'=>$id])); ?>">
                                                            <li class="	fas fa-pen"></li> แก้ไขข้อมูล
                                                        </a>

                                                        <?php if($s->status=='ban'): ?>
                                                    <a class="dropdown-item" href="<?php echo e(route('admin.memberUnban',['id'=>$id])); ?>">
                                                            <li class="	far fa-calendar-check"></li> ปลดแบน
                                                        </a>
                                                        <?php else: ?>

                                                        <a class="dropdown-item cause" href="#" data-name="<?php echo e($s->name); ?>"
                                                            data-id="<?php echo e($id); ?>">
                                                            <li class="fas fa-ban"></li> แบนผู้ใช้
                                                        </a>
                                                        <?php endif; ?>

                                                        <a class="dropdown-item" href="#">
                                                            <li class="	fas fa-trash-alt"></li> ลบผู้ใช้
                                                        </a>
                                                        <a class="dropdown-item" href="<?php echo e(route('admin.memberAbout',['id'=>$id])); ?>">
                                                            <li class="	fas fa-list-ul"></li> ดูข้อมูล
                                                        </a>


                                            </div>
                                            

                                            
                                            

                                        </td>

                                    </tr>


                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>

                        <?php echo e($user->links()); ?>

                    </div>
                </div>



            </div>
        </div>
        <!-- /.container-fluid -->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">ระบุสาเหตุการแบนผู้ใช้</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="<?php echo e(route('admin.memberBaned')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="recipient-name" class="col-form-label">แบนผู้ใช้:</label>
                                <input type="text" class="form-control" id="name" readonly>
                            </div>
                            <div class="form-group">
                                <label for="message-text" class="col-form-label">สาเหตุ:</label>
                                <textarea class="form-control" id="cause" name="cause"></textarea>
                            </div>
                            <input type="hidden" id="id" name="id">

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">ยืนยัน</button>
                        </form>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>

                    </div>
                </div>
            </div>
        </div>
        <script>
            $('.cause').click(function(){
            // get data from edit btn

            var name = $(this).attr('data-name');
            var id = $(this).attr('data-id');


            // set value to modal
            $("#name").val(name);
            $("#id").val(id);


            $('#myModal').modal('show');
            });
        </script>
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/adminNav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>